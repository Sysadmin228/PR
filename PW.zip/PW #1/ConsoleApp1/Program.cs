﻿using System;
namespace ConsoleApp1
{
    class Cars
    {
        public string Car_Name;
        public double Car_Speed;

        public Cars(string carName)
        {
            this.Car_Name = carName;
        }
        public Cars(string carName, double CarSpeed)
        {
            this.Car_Name = carName;
            this.Car_Speed = CarSpeed;
        }
        public void CarInfo()
        {
            Console.WriteLine("Название : {0}\nСкорость: {1} км/ч", Car_Name, Car_Speed);
        }
    }
    class program
    {
        public static double CalculateTime(double distance, double speed)
        {
            return (distance / speed) * 60;
        }
        static void Main()
        {
            double Speed_1; double Speed_2; double Speed_3; double Speed_4;
            string Name_1; string Name_2; string Name_3; string Name_4;

            Cars car1 = new Cars("McLaren Speedtail", 400);
            Speed_1 = car1.Car_Speed;
            Name_1 = car1.Car_Name;
            car1.CarInfo();
            Cars car2 = new Cars("Bugatti Veyron");
            car2.Car_Speed = 408;
            Speed_2 = car2.Car_Speed;
            Name_2 = car2.Car_Name;
            car2.CarInfo();
            Cars car3 = new Cars("SSC Ultimate Aero", 412);
            Speed_3 = car3.Car_Speed;
            Name_3 = car3.Car_Name;
            car3.CarInfo();
            Cars car4 = new Cars("Bugatti Chiron Super Sport");
            car4.Car_Speed = 490;
            Speed_4 = car4.Car_Speed;
            Name_4 = car4.Car_Name;
            car4.CarInfo();

            double distance = 1000;

            double Time1; double Time2; double Time3; double Time4;
            Time1 = CalculateTime(distance, Speed_1);
            Time2 = CalculateTime(distance, Speed_2);
            Time3 = CalculateTime(distance, Speed_3);
            Time4 = CalculateTime(distance, Speed_4);

            string Name; double Speed; double Time;
            if (Time1 < Time2) { Time = Time1; Name = Name_1; Speed = Speed_1; }
            else { Time = Time2; Name = Name_2; Speed = Speed_2; }
            if (Time > Time3) { Time = Time3; Name = Name_3; Speed = Speed_3; }
            if (Time > Time4) { Time = Time4; Name = Name_4; Speed = Speed_4; }

            Console.WriteLine("\nНазвание машины-победителя: {0}\nМаксимальная скорость машины: {1} км/ч\nВремя преодоления пути: {2} минут\n", Name, Speed, Time);
        }
    }


}
